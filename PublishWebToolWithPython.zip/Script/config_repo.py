portalname = 'Your_portal_name'
fedservername = 'Your_federated_server_name'
username = 'portal_username'
password = 'portal_password'

connectionfilepath = 'https://{}/server'.format(fedservername)
uncpath = r"Your server UNC folder path for server data store"

 
 
