#**************************************************************************************************************************************
#                                                           Publish  Web  Tool 
#**************************************************************************************************************************************


import arcpy
import config
import os
import sys

arcpy.CheckOutExtension("Spatial")
arcpy.env.overwriteOutput = True


# Set workspace and scratch folder
ws = arcpy.env.workspace = r'e:\UC\UC2020\ViewshedMap'
sc = arcpy.env.scratchworkspace = os.path.join(ws, 'Scratch')


# Set input and output data then run the model
intbx = 'ViewshedMap.tbx'
inputfc = os.path.join('ViewshedMap.gdb', 'destination')
inputRaster = os.path.join('ViewshedMap.gdb', 'elevation')
rasterlayer = "rasterlyr1"
rasterformat ='GRID'
outRaster = "%scratchFolder%\Rasteroutput"

try:    
    arcpy.management.MakeRasterLayer(inputRaster, rasterlayer)
    arcpy.ImportToolbox(intbx)
    result_item = arcpy.ViewshedSelect_Viewshed(inputfc, rasterlayer, rasterformat, outRaster)
    print("Tool runs successfully.")
except:
    print("Making layer or running tool error:", sys.exc_info()[0])    
    