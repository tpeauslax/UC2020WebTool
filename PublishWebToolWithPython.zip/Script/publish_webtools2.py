#**************************************************************************************************************************************
#                                                           Publish  Web  Tool 2
#**************************************************************************************************************************************


import arcpy
import config
import os
import sys

arcpy.CheckOutExtension("Spatial")
arcpy.env.overwriteOutput = True


# Set workspace and scratchr folder

ws = arcpy.env.workspace =  r"c:\UC2020\PublishPython\ViewshedMap"
sc = arcpy.env.scratchworkspace = os.path.join(ws, 'Scratch')


# Sign in Portal
try:
    arcpy.SignInToPortal('https://{}/portal/'.format(config.portalname), config.username, config.password)
    print('Signed in to portal')
except:
    print("Signin error:", sys.exc_info()[0])

# Add Folder Data Store 
try:
    arcpy.AddDataStoreItem("MY_HOSTED_SERVICES", "FOLDER", "AddedFolder", config.uncpath, ws)
    print('Add folder data store')
except:
    print("Add Data Store item error:", sys.exc_info()[0])    

# Set input and output data then run the model
intbx = 'ViewshedMap.tbx'
inputfc = os.path.join('ViewshedMap.gdb', 'destination')
inputRaster = os.path.join(ws, 'ViewshedMap.gdb', 'elevation')

rasterlayer = 'rasterlyr'
rasterformat ='GRID'
outRaster = "%scratchFolder%\Rasteroutput"

try:    
    returnlyr = arcpy.management.MakeRasterLayer(inputRaster, rasterlayer)
    arcpy.ImportToolbox(intbx)
    result_item = arcpy.ViewshedMap.ViewshedSelect(inputfc, rasterlayer, rasterformat, outRaster)
    print("Tool runs successfully.")

except:
    print("Making layer or running tool error:", sys.exc_info()[0])    
    
 
# Publish web tool
try:    
    # Create a service definition draft
    draft_file = os.path.join(sc,'webtools.sddraft')
    draft_file_return = arcpy.CreateGPSDDraft(result = result_item,
                                          out_sddraft = draft_file,
                                          service_name = 'viewshed2',
                                          server_type = "MY_HOSTED_SERVICES",
                                          connection_file_path = config.connectionfilepath,
                                          constantValues = ['ViewshedSelect.Format'])
    
    print("Service Definition Draft is ready.")
    
    # Analyze the return from creating the service definition draft
    if (draft_file_return['errors']):
        print(draft_file_return['errors'])
    else:
        print(draft_file_return['warnings'])
    
        # Stage the service
        definition_file = os.path.join(sc, 'webtools.sd')
        arcpy.StageService_server(draft_file, definition_file)
        print("Service staged.")
    
        #Upload service definition
        arcpy.UploadServiceDefinition_server(definition_file,'https://{}/server'.format(config.fedservername))
        print("Service published.")
        
except:
    print("Publishing error:", sys.exc_info()[0])    
    
# Remove Folder Data Store 
try:
    arcpy.RemoveDataStoreItem("MY_HOSTED_SERVICES", "FOLDER", "AddedFolder")
except:
    print("Remove Data Store item error:", sys.exc_info()[0])      