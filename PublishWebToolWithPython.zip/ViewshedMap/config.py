portalname = 'ne.esri.com'
fedservername = 'ne.esri.com'
username = 'admin'
password = 'esri.agp'


uncpath = r"C:\UC2020\PublishPython\Data"

 
 